# Module 12 Report

## Overview of the Analysis
* **Purpose**: Develop a machine learning model to predict loan risk
* **Financial Information**: Loan data including loan size, interest rate, borrower income, debt-to-income ratio, number of accounts, derogatory marks, and total debt
* **Prediction Goal**: Classify loans as either healthy (0) or high-risk (1)

* **Data Distribution**:
  - Total loans analyzed
  - Majority of loans are healthy (0)
* **Machine Learning Process**:
  1. Data preprocessing
  2. Splitting data into training and testing sets
  3. Logistic Regression model training
  4. Model evaluation

## Results
* Machine Learning Model (Logistic Regression):
    * **Accuracy**: 0.99 (99%)
    * **Precision**:
      - Healthy Loans (0): 1.00
      - High-Risk Loans (1): 0.85
    * **Recall**:
      - Healthy Loans (0): 0.99
      - High-Risk Loans (1): 0.95
    * **Confusion Matrix**:
      - True Negatives (Healthy Loans Correctly Predicted): 18,658
      - False Positives: 107
      - False Negatives: 34
      - True Positives (High-Risk Loans Correctly Predicted): 585

## Summary
* **Model Performance**: Very good prediction capability
* **Recommendation**: Strongly recommend using this model
* **Justification**:
  - High overall accuracy (99%)
  - Near-perfect prediction of healthy loans
  - Strong performance in identifying high-risk loans
  - Low false negative rate (important for risk management)
* **Considerations**:
  - Slightly lower precision for high-risk loans
  - Minimal misclassification of high-risk loans

The model provides a robust tool for initial loan risk assessment.